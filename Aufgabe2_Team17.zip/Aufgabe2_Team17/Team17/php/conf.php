<?php
//Config Settings

/*
Relative path to the world data csv
*/
define("WORLD_DATA_PATH", "../ressourcen/data/world_data_v1.csv");

/*
Relative path where the xml file should be saved
*/
define("XML_PATH",    "../ressourcen/data/world_data.xml");

/*
Relative path to the xslt to transform world data xml to a html table
*/
define("XSL_PATH",    "../ressoucen/data/world_data.xsl");


?>